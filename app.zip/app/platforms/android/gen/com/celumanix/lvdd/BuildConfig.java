/** Automatically generated file. DO NOT MODIFY */
package com.celumanix.lvdd;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}