var screen_faqs = $("#screen_faqs");
screen_faqs.show = function(){focus_trivia = false; screen_faqs.removeClass('downed');};
screen_faqs.hide = function(){focus_trivia = true; screen_faqs.addClass('downed');};
